//
//  ViewController.swift
//  FirstExample
//
//  Created by MacStudent on 2017-10-12.
//  Copyright © 2017 Kalpana Ramanan. All rights reserved.
//

import UIKit

class LoginViewController: UIViewController {
    
    @IBOutlet var btnSubmit:UIButton?
    @IBOutlet weak var txtUserName: UITextField!
    @IBOutlet weak var txtPassword: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func loginClick(_ sender: UIButton) {
        
        //Create Alert Controller Object
        var alert:UIAlertController!
        
        if ((txtUserName.text == "admin") && (txtPassword.text == "admin")){
            
            /*
            alert  = UIAlertController(title: "Message", message: "Welcome to iOS Progrmming", preferredStyle: UIAlertControllerStyle.alert)
           
            // OK Button
            let actionOK = UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler:
                {
                    _ in  print("Hello, Welcome to iOS Programming \(self.txtUserName.text!)")
                }
            )
            alert?.addAction(actionOK)
 */
           
           let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
            let employeeViewController = storyBoard.instantiateViewController(withIdentifier: "employeeScreen") as! EmployeeViewController
            self.present(employeeViewController, animated: true, completion: nil)
            
            
        }else{
          
            alert  = UIAlertController(title: "Message", message: "Incorrect Pls try agian", preferredStyle: UIAlertControllerStyle.alert)
            
            // Cancel Button
            let actionCancel = UIAlertAction(title: "Cancel", style: UIAlertActionStyle.cancel, handler: {
                _ in print("Incorrect Username!!! Please try again");
            })
            alert.addAction(actionCancel)
            self.present(alert, animated: true, completion: nil)

            
        }
       

    }
    
}

