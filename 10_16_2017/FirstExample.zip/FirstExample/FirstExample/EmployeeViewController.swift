//
//  EmployeeViewController.swift
//  FirstExample
//
//  Created by MacStudent on 2017-10-16.
//  Copyright © 2017 Kalpana Ramanan. All rights reserved.
//

import UIKit

class EmployeeViewController: UIViewController {

    @IBOutlet weak var txtEmpId: UITextField!
    @IBOutlet weak var txtEmpName: UITextField!
    @IBOutlet weak var txtBirthDate: UITextField!
    @IBOutlet weak var txtSalary: UITextField!
    
  
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    @IBAction func saveEmployee(_ sender: UIButton) {
        //Create Alert Controller Object
        var alert:UIAlertController!
      
        let employee = Employee();
        
        employee.empId = Int(txtEmpId.text!);
        employee.empName = String(txtEmpName.text!);
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd-mm-yyyy"
        dateFormatter.timeZone = TimeZone(abbreviation: "GMT+0:00")
        employee.birthDate = dateFormatter.date(from: txtBirthDate.text!)
        
        employee.salary = Double(txtSalary.text!)
       
        let flag =   Employee.addEmployee(emp: employee);
        if(flag){
            alert  = UIAlertController(title: "Message", message: "Record saved successfully", preferredStyle: UIAlertControllerStyle.alert)
            
            // Save Button
            let actionSave = UIAlertAction(title: "Saved", style: UIAlertActionStyle.cancel, handler: {
                _ in print("Record saved successfully");
            })
            alert.addAction(actionSave)
            self.present(alert, animated: true, completion: nil)
            clearEmployeeInfo();
        }else{
            
            alert  = UIAlertController(title: "Message", message: "Employee Already Exist", preferredStyle: UIAlertControllerStyle.alert)
            
            // cancel Button
            let actionSave = UIAlertAction(title: "Cancel", style: UIAlertActionStyle.cancel, handler: {
                _ in print("Employee Already Exist");
            })
            alert.addAction(actionSave)
            self.present(alert, animated: true, completion: nil)
        }
    }
    
    func clearEmployeeInfo(){
        txtEmpId.text = "";
        txtEmpName.text = "";
        txtSalary.text = "";
        txtBirthDate.text = "";
    }
    
    
    @IBAction func SearchByEmpID(_ sender: UIButton) {
    
        let  employee = Employee.getEmployeeByID(empId: Int(txtEmpId.text!)!);
        print(employee.empName)
        
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
