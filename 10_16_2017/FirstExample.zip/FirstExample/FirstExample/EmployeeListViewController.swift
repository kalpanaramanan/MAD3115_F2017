//
//  EmployeeListViewController.swift
//  FirstExample
//
//  Created by MacStudent on 2017-10-16.
//  Copyright © 2017 Kalpana Ramanan. All rights reserved.
//

import UIKit

class EmployeeListViewController: UIViewController {

    
    @IBOutlet weak var lblEmpdata: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let empList = Employee.getAllEmployee()
        var s = String()
        s.append("*** EMPLOYEE DETAILS ***");
        for (key, value) in empList{
            s.append("\nEmployee ID: \(key) -- > \nEmployee Name: \(value.empName!)\nEmployee Salary: \(value.salary!) \nEmployee BirthDate: \(value.birthDate!)");
        }
        lblEmpdata.text = s
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
