//
//  ViewController.swift
//  MapKitExample
//
//  Created by moxDroid on 2017-10-27.
//  Copyright © 2017 moxDroid. All rights reserved.
//

import UIKit
import MapKit

class ViewController: UIViewController {
    @IBOutlet weak var myMap: MKMapView!
    let initialLocation = CLLocation(latitude: 43.6532, longitude: -79.3832)
    let lambtonCollegeLocation = CLLocation(latitude: 43.773257, longitude: -79.335899)
    
   let mumbaiCityLocation = CLLocation(latitude: 19.075984, longitude: 72.877656)
    
    let regionRadius: CLLocationDistance = 1000
    
    var locationManager = CLLocationManager()
    
    let mumbaiCityLocation1 = CLLocation(latitude: 51.503454, longitude: -0.119562)
    let mumbaiCityLocation2 = CLLocation(latitude: 51.499633, longitude: -0.124755)
    
    override func viewDidLoad() {
        super.viewDidLoad()
        myMap.mapType = MKMapType.hybrid
        myMap.isPitchEnabled = true
        myMap.isZoomEnabled = true
        myMap.isScrollEnabled = true
        myMap.showsUserLocation = true
        
      // centerMapOnLocation(location: initialLocation)
      // setPoinAnotation(location: initialLocation, title: "City Hall", subTitle: "123 King Street W")
        
      //  centerMapOnLocation(location: lambtonCollegeLocation)
      // setPoinAnotation(location: lambtonCollegeLocation, title: "Lambton College", subTitle: "267 Yorkland Blvd., North York")
        
      //  centerMapOnLocation(location: mumbaiCityLocation)
      //  setPoinAnotation(location: mumbaiCityLocation, title: "Mumbai City", subTitle: "Downtown, Mumbai, India")
        
        centerMapOnLocation(location: mumbaiCityLocation1)
        setPoinAnotation(location: mumbaiCityLocation1, title: "London Eye", subTitle: "345 London, London, London")
        
        centerMapOnLocation(location: mumbaiCityLocation2)
        setPoinAnotation(location: mumbaiCityLocation2, title: "Palace of Westminster", subTitle: "678 London, London, London")

        
        
         //Ask from permission dialog to access current location
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        locationManager.requestWhenInUseAuthorization()
        locationManager.delegate = self
        DispatchQueue.main.async {
            //self.locationManager.startUpdatingLocation()
        }
    }
    
    func centerMapOnLocation(location: CLLocation) {
        let coordinateRegion = MKCoordinateRegionMakeWithDistance(location.coordinate,
                                                                  regionRadius, regionRadius)
        myMap.setRegion(coordinateRegion, animated: true)
    }
    
    func setPoinAnotation(location: CLLocation,title: String, subTitle: String){
        
        //Clear all pointer
//        if self.myMap.annotations.count != 0{
//            for i in 0..<self.myMap.annotations.count
//            {
//                let annotation = self.myMap.annotations[i]
//                self.myMap.removeAnnotation(annotation)
//            }
//        }
        
//        if self.myMap.annotations.count != 0{
//            let annotation = self.myMap.annotations[0]
//            self.myMap.removeAnnotation(annotation)
//        }
        // Drop a pin at user's Current Location
        let myAnnotation: MKPointAnnotation = MKPointAnnotation()
        myAnnotation.coordinate = CLLocationCoordinate2DMake(location.coordinate.latitude, location.coordinate.longitude);
        myAnnotation.title = title
        myAnnotation.subtitle = subTitle
        myMap.addAnnotation(myAnnotation)
    }
    
    @IBAction func chengeMapType(_ sender: UISegmentedControl) {
        
        if sender.selectedSegmentIndex == 0{
            myMap.mapType = MKMapType.standard
        }else{
            myMap.mapType = MKMapType.satellite
        }
    }

}

extension ViewController: CLLocationManagerDelegate{
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        
        let currentLocation = locations[0]
        
        self.setPoinAnotation(location: currentLocation, title: "Current Location", subTitle: "Sub title")
    }
    
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        print("Error : No location found")
    }
}
