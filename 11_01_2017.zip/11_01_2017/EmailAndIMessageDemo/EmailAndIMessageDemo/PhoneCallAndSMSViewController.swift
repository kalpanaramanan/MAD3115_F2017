//
//  PhoneCallAndSMSViewController.swift
//  EmailAndIMessageDemo
//
//  Created by MacStudent on 2017-11-01.
//  Copyright © 2017 MacStudent. All rights reserved.
//

import UIKit
import MessageUI


class PhoneCallAndSMSViewController: UIViewController,MFMessageComposeViewControllerDelegate {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    
      //Send SMS
    @IBAction func sendMessage(_ sender: UIButton) {
        
        if MFMessageComposeViewController.canSendText() {
            
            
            let messageVC = MFMessageComposeViewController()
            messageVC.body = "Hello, How are you?"
            messageVC.recipients = ["+16477200342"]
            messageVC.messageComposeDelegate = self
            
            self.present(messageVC, animated: false, completion: nil)
        }
    }
    
  
   
    
    func messageComposeViewController(_ controller: MFMessageComposeViewController, didFinishWith result: MessageComposeResult)
    {
        
        switch (result) {
        case .cancelled:
            print("Message was cancelled")
            self.dismiss(animated: true, completion: nil)
        case .failed:
            print("Message failed")
            self.dismiss(animated: true, completion: nil)
        case .sent:
            print("Message was sent")
            self.dismiss(animated: true, completion: nil)
        }
    }
    
    ///Make Phone Call
    @IBAction func makePhoneCall(_ sender: UIButton) {
        if let url = URL(string: "tel://+16477200342)"), UIApplication.shared.canOpenURL(url){
            if #available(iOS 10, *)
            {
                UIApplication.shared.open(url)
            }
            else
            {
                UIApplication.shared.openURL(url)
            }
        }
    }

}
