//
//  EmailViewController.swift
//  EmailAndIMessageDemo
//
//  Created by MacStudent on 2017-11-01.
//  Copyright © 2017 MacStudent. All rights reserved.
//

import UIKit
import MessageUI

class EmailViewController: UIViewController,MFMailComposeViewControllerDelegate {

    @IBOutlet var subject: UITextField!
    @IBOutlet var body: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    @IBAction func sendMail(_ sender: UIButton) {
        if MFMailComposeViewController.canSendMail() {
            print("Send Mail Sucessfully");
            let picker = MFMailComposeViewController()
            picker.mailComposeDelegate = self
            picker.setSubject(subject.text!)
            picker.setMessageBody(body.text!, isHTML: true)
            present(picker, animated: true, completion: nil)
        }else{
            print("Didnt send Mail");
        }
    }
   
    // MFMailComposeViewControllerDelegate
    func messageComposeViewController(_ controller: MFMessageComposeViewController, didFinishWith result: MessageComposeResult) {
        dismiss(animated: true, completion: nil)
    }

}
