//
//  ViewController.swift
//  TableViewController
//
//  Created by MacStudent on 2017-10-23.
//  Copyright © 2017 MacStudent. All rights reserved.
//

import UIKit

class ViewController: UIViewController{
 
    let countryNames = ["India","Afghanistan","Bahrain","Brazil","Ecuador","Finland","Japan","UK","Sweden","Russia"];
    @IBOutlet weak var countryTableView: UITableView!
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        self.countryTableView.dataSource = self;
        self.countryTableView.delegate = self;
    
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

extension ViewController : UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return countryNames.count;
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "countryNameCell")!;
        cell.textLabel?.textColor = UIColor.red;
        cell.textLabel?.text = "Title";
        cell.detailTextLabel?.text  = countryNames[indexPath.row];
        return cell;
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1;
    }
}

extension ViewController : UITableViewDelegate{
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        print(countryNames[indexPath.row]);
    }
}
