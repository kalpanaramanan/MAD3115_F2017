//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

extension Array {
    /// Returns an array containing this sequence shuffled
    var shuffled: Array {
        var elements = self
        return elements.shuffle()
    }
    /// Shuffles this sequence in place
    @discardableResult
    mutating func shuffle() -> Array {
        let count = self.count
        indices.dropLast().forEach {
            swapAt($0, Int(arc4random_uniform(UInt32(count - $0))) + $0)
        }
        return self
    }
    var chooseOne: Element { return self[Int(arc4random_uniform(UInt32(count)))]
    }
}
var alphabet = ["A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z"]
let shuffledAlphabet = alphabet.shuffled

let letter = alphabet.chooseOne

var numbers = Array(0...9)
    numbers = Array(10...19)

let shuffledNumbers = numbers.shuffled
shuffledNumbers                              // [8, 9, 3, 6, 0, 1, 4, 2, 5, 7]

numbers            // [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]

numbers.shuffle().count // mutate it  [6, 0, 2, 3, 9, 1, 5, 7, 4, 8]
numbers.shuffle()
numbers.shuffle()

alphabet.shuffle();
alphabet.shuffle();
alphabet.shuffle();



numbers            // [6, 0, 2, 3, 9, 1, 5, 7, 4, 8]

//let pick3numbers = numbers.choose(3)  // [8, 9, 2]




