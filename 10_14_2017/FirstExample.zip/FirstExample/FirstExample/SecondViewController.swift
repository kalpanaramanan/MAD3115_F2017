//
//  SecondViewController.swift
//  FirstExample
//
//  Created by MacStudent on 2017-10-13.
//  Copyright © 2017 Kalpana Ramanan. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {

    @IBOutlet weak var mySwitch: UISwitch!
    @IBOutlet var myTextField: UITextField!
    @IBOutlet weak var myProgressBar: UIProgressView!
    
    var iFloat: Float?
    var timer: Timer?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        showProgress()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func btnMyAlert(_ sender: UIButton) {
       
        //Create Alert Controller Object
        let alert  = UIAlertController(title: "Message", message: "Welcome to iOS Progrmming", preferredStyle: UIAlertControllerStyle.actionSheet)
        
       // OK Button
        let actionOK = UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler:nil)
        alert.addAction(actionOK)
        
        // Cancel Button
        let actionCancel = UIAlertAction(title: "Cancel", style: UIAlertActionStyle.cancel, handler: nil)
        alert.addAction(actionCancel)
        
        // Retry Button
        let actionRetry = UIAlertAction(title: "Retry", style: UIAlertActionStyle.default, handler: nil)
        alert.addAction(actionRetry)
        
        //Confirm Button
        let actionConfirm = UIAlertAction(title: "Confirm", style: UIAlertActionStyle.default, handler:
           {
                _ in print("Confirm")
            }
            
        )
           
        alert.addAction(actionConfirm)
        
        
        self.present(alert, animated: true, completion: nil)
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    
    @IBAction func mySwitchTapped(_ sender: UISwitch)
    {
        if mySwitch.isOn
        {
            myTextField.text = "The Switch is On"
        }
        else
        {
            myTextField.text = "The Switch is Off"
        }
    }
    
    @IBAction func buttonClicked(_ sender: UIButton)
    {
        if mySwitch.isOn
        {
            myTextField.text = "The Switch is Off"
            mySwitch.setOn(false, animated:true)
        }
        else
        {
            myTextField.text = "The Switch is On"
            mySwitch.setOn(true, animated:true)
        }
    }
    
    
    @IBAction func mySliderChange(_ sender: UISlider) {
        
        myTextField.text = " Slider \(Int(sender.value))"
        myProgressBar.progress = (Float(sender.value)/100) ;
    }
    
    
    func showProgress(){
        
        iFloat = 0
        timer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(self.update), userInfo: nil, repeats: true)
        
        DispatchQueue.global(qos: .utility).async {
            
            DispatchQueue.main.async {
                print(self.iFloat!)
                self.iFloat = self.iFloat! + 0.1
                self.myProgressBar.setProgress(self.iFloat!, animated: true)
            }
        }
    }
    @objc func update() {
        if iFloat  == 1 {
            if timer != nil {
                timer!.invalidate()
                timer = nil
            }
        }
        iFloat = iFloat! + 0.1
        myProgressBar.setProgress(iFloat!, animated: true)
    }
}
