//
//  Registration.swift
//  HealthHabits
//
//  Created by Kalpana Ramanan on 2017-10-24.
//  Copyright © 2017 MacStudent. All rights reserved.
//

import Foundation

class Registration {
    
    var userId:Int;
    var userName:String;
    var password:String;
    var phoneNumber:String;
    var address:String;
    var userDic = [Int:String]();
    
    init(){
        self.userId = 1;
        self.userName = "";
        self.password = "";
        self.phoneNumber = "";
        self.address = "";
    }
    
    init(_ userId:Int,_ userName:String,_ password:String,_ phoneNumber:String,_ address:String){
        self.userId = userId;
        self.userName = userName;
        self.password = password;
        self.phoneNumber = phoneNumber;
        self.address = address;
    }
    
    static func addNewUser(){
        
    }
    
}
