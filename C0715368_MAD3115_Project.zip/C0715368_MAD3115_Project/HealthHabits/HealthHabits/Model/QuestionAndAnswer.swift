//
//  QuestionAndAnswer.swift
//  HealthHabits
//
//  Created by Kalpana Ramanan on 2017-10-26.
//  Copyright © 2017 MacStudent. All rights reserved.
//

import Foundation

class QuestionAndAnswer{
    var questionIndex:Int?;
    var question:String?
    var answer1:String?
    var answer2:String?
    var answer3:String?
    var answer4:String?
    var correctAnswer:String?

    init(){
        self.questionIndex = 0;
        self.question = "";
        self.answer1 = "";
        self.answer2 = "";
        self.answer3 = "";
        self.answer4 = "";
        self.correctAnswer = "";
    }

    init(_ questionIndex:Int,_ question:String,_ answer1:String,_ answer2:String,_ answer3:String,_ answer4:String,_ correctAnswer:String){
        self.questionIndex = questionIndex;
        self.question = question;
        self.answer1 = answer1;
        self.answer2 = answer2;
        self.answer3 = answer3;
        self.answer4 = answer4;
        self.correctAnswer = correctAnswer;
    }
    
   static  func addQuestionArray()-> [QuestionAndAnswer] {
    let aQuestion = QuestionAndAnswer(0,"What sweet food made by bees using nectar from flowers? ","Honey","Sugar","Flower","None","Honey")
    let bQuestion = QuestionAndAnswer(1,"Which country is home to the kangaroo?","India","Spain","Australia","Canada","Australia")
    let cQuestion = QuestionAndAnswer(2,"What is the top colour in a rainbow?","Green","Red","Violet","Blue","Red")
    let dQuestion = QuestionAndAnswer(3,"In the nursery rhyme, who sat on a wall before having a great fall?","Humpty","Dumpty","Pan","Humpty Dumpty","Humpty Dumpty")
    let eQuestion = QuestionAndAnswer(4,"What is the name of the toy cowboy in Toy Story?","Peter Pan","Harry","Aam","Woody","Woody")
    let fQuestion = QuestionAndAnswer(5,"Pharaoh is the title given to the rulers of which ancient county?","Iran","Egypt","USA","None","Egypt")
    let gQuestion = QuestionAndAnswer(6,"Which Italian city is famous for its leaning tower?","Quis","Liza","Pisa","Italian","Pisa")
    let hQuestion = QuestionAndAnswer(7,"What is the name of Harry Potter’s pet owl? ","Hedwig","Zedwig","Eedwig","Gedwig","Hedwig")
    let iQuestion = QuestionAndAnswer(8,"What food do Giant Pandas normally eat?","Plant","Bamboo","Leaves","Fruits","Bamboo")
    let jQuestion = QuestionAndAnswer(9,"How many years are there in a millennium? ","100","2000","1000","10000","1000")
    let kQuestion = QuestionAndAnswer(10," In Jungle Book what kind of animal is Baloo?","Bear","Wolf","Monkey","Tiger","Bear")
    let lQuestion = QuestionAndAnswer(11,"What is the name of the fairy in Peter Pan?","Harry Poter","Twilight","TinkerBell","Goodle","TinkerBell")
    let mQuestion = QuestionAndAnswer(12,"What colour are Smurfs?","White","Black","Yellow","Pink","Blue")
    
    let quesDitonary = [aQuestion,bQuestion,cQuestion,dQuestion,eQuestion,fQuestion,gQuestion,hQuestion,iQuestion,jQuestion,kQuestion,lQuestion,mQuestion];
        return quesDitonary;
    }
    
}
