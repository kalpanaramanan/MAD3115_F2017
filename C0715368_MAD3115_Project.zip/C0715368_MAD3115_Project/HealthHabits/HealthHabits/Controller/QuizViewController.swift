//
//  QuizViewController.swift
//  HealthHabits
//
//  Created by MacStudent on 2017-10-18.
//  Copyright © 2017 MacStudent. All rights reserved.
//

import UIKit

class QuizViewController: UIViewController {
    
    @IBOutlet weak var lblQuestion: UILabel!
    @IBOutlet weak var btnRadioGroup: DLRadioButton!
    @IBOutlet weak var btnNext: UIButton!
    @IBOutlet weak var btnResult: UIButton!
    @IBOutlet weak var countDownLabel: UILabel!
    
    @IBOutlet weak var btnAnswer2: DLRadioButton!
    @IBOutlet weak var btnAnswer3: DLRadioButton!
    @IBOutlet weak var btnAnswer4: DLRadioButton!

    
    var correctAnswer = 0;
    var skippedQuestion  = 0;
    var incorrectQuestion = 0;
    var flag:Int = 0;
    
    var timerCount = 0;
    var timer = Timer();
    var count = 0 ;
    var questionArray = QuestionAndAnswer.addQuestionArray();
    var questionOriginalArray = [String]();
    var answerCorrect =  String();
    
    
    @objc func updateCounter() {
        //you code, this is an example
        if timerCount >= 0 {
           // print("\(timerCount) seconds to the end of the world")
            let timerData = "\(timerCount) Secs"
            countDownLabel.text = timerData;
            timerCount -= 1
        }else{
            if(count != 10){
                clearAllData();
                timerCount = 10;
                getQuestionAndAnswers();
                getFlagData();
                count += 1;
            }
            if(count==10){
                btnNext.isHidden = true;
                btnResult.isHidden = false;
            }
        }
    }
    
    @IBAction func onClickLogout(_ sender: UIBarButtonItem) {
        timer.invalidate();
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let mainViewController = storyBoard.instantiateViewController(withIdentifier: "tabBarScreen") as! UITabBarController
      // self.present(mainViewController, animated: true, completion: nil);
        self.present(mainViewController, animated: true, completion: nil);

    }
    
    fileprivate func moveToNextQuestion(){
        timerCount = 10;
        getQuestionAndAnswers();
        
        btnNext.isHidden = true;
        btnResult.isHidden = false;
        
        getFlagData();
        count += 1;
    }
    override func viewDidLoad() {
        super.viewDidLoad();
        btnResult.applyButtonCssStyle2();
        btnNext.applyButtonCssStyle2();
        
        timerCount = 10;
        timer =  Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(updateCounter), userInfo: nil, repeats: true);
        btnRadioGroup.isMultipleSelectionEnabled = false;
        btnResult.isHidden = true;
        questionArray = questionArray.shuffle();
        getQuestionAndAnswers();
        count += 1;
    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.navigationBar.isHidden = false
    }

    func getQuestionAndAnswers(){
        answerCorrect = String(describing: questionArray[count].correctAnswer!);
        lblQuestion.text = "\(count + 1) .  \(questionArray[count].question!)";
        btnRadioGroup.setTitle(questionArray[count].answer1!, for: UIControlState.normal)
        btnAnswer2.setTitle(questionArray[count].answer2!, for: UIControlState.normal)
        btnAnswer3.setTitle(questionArray[count].answer3!, for: UIControlState.normal)
        btnAnswer4.setTitle(questionArray[count].answer4!, for: UIControlState.normal)
    }
   

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    func clearAllData(){
        btnRadioGroup.isSelected = false
        btnAnswer2.isSelected = false;
        btnAnswer3.isSelected = false;
        btnAnswer4.isSelected = false;
    }
   
    @IBAction func onClickNext(_ sender: UIButton) {
        clearAllData();
        timerCount = 10;
        getQuestionAndAnswers();
        
        if(count == 9){
            btnNext.isHidden = true;
            btnResult.isHidden = false;
        }
        getFlagData();
        count += 1;
    }
    
   
    @IBAction func btnResults(_ sender: UIButton) {
       timer.invalidate();
        getFlagData();
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let resultViewController = storyBoard.instantiateViewController(withIdentifier: "resultScreen") as! ResultViewController
        resultViewController.correctAnswer = correctAnswer;
        resultViewController.incorrectQuestion = incorrectQuestion;
        resultViewController.skippedQuestion = skippedQuestion;
         //self.present(resultViewController, animated: true, completion: nil);
        self.navigationController?.pushViewController(resultViewController, animated: true)

    }
    

    @IBAction func btnOnClickRadioButton(_ sender: DLRadioButton) {
        if(sender.isSelected == true){
            if(sender.titleLabel!.text! == answerCorrect){
                flag = 1;
            }else{
                flag = 2
            }
        }else{
            flag = 0;
        }
    }
    
    func getFlagData(){
        if(flag == 1){
            correctAnswer += 1;
        }else if(flag == 2){
            incorrectQuestion  += 1;
        }else if(flag == 0){
            skippedQuestion += 1;
        }
        flag = 0;
    }
}

extension Array {
    /// Returns an array containing this sequence shuffled
    var shuffled: Array {
        var elements = self
        return elements.shuffle()
    }
    /// Shuffles this sequence in place
    @discardableResult
    mutating func shuffle() -> Array {
        let count = self.count
        indices.dropLast().forEach {
            swapAt($0, Int(arc4random_uniform(UInt32(count - $0))) + $0)
        }
        return self
    }
    var chooseOne: Element { return self[Int(arc4random_uniform(UInt32(count)))]
    }
}

extension UIButton{
    func applyButtonCssStyle2(){
        self.backgroundColor = UIColor.darkGray;
        self.layer.cornerRadius = self.frame.height / 2;
        self.setTitleColor(UIColor.white, for: UIControlState.normal);
        self.titleLabel?.font = UIFont.boldSystemFont(ofSize: 16)
        
        self.layer.shadowColor =    UIColor.white.cgColor;
        self.layer.shadowRadius = 2;
        self.layer.shadowOpacity = 0.5;
        self.layer.shadowOffset = CGSize(width:0,height:0);
    }
}
