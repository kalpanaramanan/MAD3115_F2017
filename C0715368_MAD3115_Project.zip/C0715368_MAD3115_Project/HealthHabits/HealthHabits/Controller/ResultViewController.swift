//
//  ResultViewController.swift
//  HealthHabits
//
//  Created by MacStudent on 2017-10-24.
//  Copyright © 2017 MacStudent. All rights reserved.
//

import UIKit

class ResultViewController: UIViewController {
    
    @IBOutlet weak var lblOutput: UILabel!
    
    var defaults = UserDefaults.standard;
    @IBOutlet weak var lblTotalResults: UILabel!
    
    var correctAnswer = 0;
    var skippedQuestion  = 0;
    var incorrectQuestion = 0;
    var previousScore = 0 ,currentScore = 0;
    override func viewDidLoad() {
        super.viewDidLoad();
        
        lblTotalResults.text = String(describing:"You have answered \(correctAnswer) out of 10 ");
        lblOutput.text = String(describing:"Your correct answer : \(correctAnswer)\nYour Incorrect Answer : \(incorrectQuestion)\n Your skipped Answer :\(skippedQuestion)")
        print(defaults.integer(forKey: "noOfAttempts") ,"Result Page")
   
        if (defaults.integer(forKey: "score") == 0 ){
        defaults.set(correctAnswer, forKey: "score");
        }else if (correctAnswer > defaults.integer(forKey: "score")){
             defaults.set(correctAnswer, forKey: "score");
        }else if (correctAnswer < defaults.integer(forKey: "score")){
        previousScore = defaults.integer(forKey: "score")
        defaults.set(previousScore, forKey: "score");
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
 
    @IBAction func onClickHome(_ sender: UIBarButtonItem) {
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let mainViewController = storyBoard.instantiateViewController(withIdentifier: "tabBarScreen") as! UITabBarController
       // self.present(mainViewController, animated: true, completion: nil);
        self.navigationController?.pushViewController(mainViewController, animated: true)

    }
    
}
