//
//  StatisticsViewController.swift
//  HealthHabits
//
//  Created by Kalpana Ramanan on 2017-10-31.
//  Copyright © 2017 MacStudent. All rights reserved.
//

import UIKit

class StatisticsViewController: UIViewController {
    @IBOutlet weak var lblNoOfAttempts: UILabel!
    @IBOutlet weak var lblScore: UILabel!
    var defaults = UserDefaults.standard;

    override func viewDidLoad() {
        super.viewDidLoad()
        
        let result = "No Of Attempts: \(defaults.integer(forKey: "noOfAttempts"))"
        lblNoOfAttempts.text = result;
        let score = "Your Highest Score is: \(defaults.integer(forKey: "score"))"
        lblScore.text = score;
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
