//
//  LoginViewController.swift
//  HealthHabits
//
//  Created by MacStudent on 2017-10-18.
//  Copyright © 2017 MacStudent. All rights reserved.
//

import UIKit

class LoginViewController: UIViewController {
    @IBOutlet weak var txtUserName: UITextField!
    @IBOutlet weak var txtPassword: UITextField!
    @IBOutlet weak var mySwitch: UISwitch!
    @IBOutlet weak var btnSubmit: UIButton!
    
    var defaults = UserDefaults.standard;

    override func viewDidLoad() {
        super.viewDidLoad();
        // Do any additional setup after loading the view.

        let value = String(describing: defaults.value(forKey: "UserName"));
        if(value == "nil"){
            txtUserName.text = "";
        }else{
            txtUserName.text = String(describing: defaults.value(forKey: "UserName")!);
        }
        btnSubmit.applyButtonCssStyle1();
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    fileprivate func onClickSwitch() {
        let name = txtUserName.text!
        if mySwitch.isOn
        {
            print ("The Switch is On")
            defaults.set(name, forKey: "UserName");
        }else{
            print("The Switch is Off")
            defaults.removeObject(forKey: "UserName")
        }
    }
    
    @IBAction func mySwitchTapped(_ sender: UISwitch) {
        onClickSwitch();
    }
    
    
    func checkNoOfAttempts() -> Int{
        var a:Int = 0;
        let value = defaults.integer(forKey: "noOfAttempts")
        if(value == 0){
            a = 1;
        }else{
            a = value + 1;
        }
        return a;
    }

    @IBAction func onClickSubmit(_ sender: UIButton) {
        onClickSwitch();
        if( txtUserName.text == "admin" && txtPassword.text == "admin"){
            defaults.set(checkNoOfAttempts(), forKey: "noOfAttempts");
            let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
            let quizViewController = storyBoard.instantiateViewController(withIdentifier: "quizScreen") as! QuizViewController
            self.navigationController?.pushViewController(quizViewController, animated: true);
            //self.present(quizViewController, animated: true, completion: nil);
        }else{            
            let alert = UIAlertController(title: "Message", message: "Incorrect User", preferredStyle: UIAlertControllerStyle.alert);
            //Cancel Action
            let cancelAction =  UIAlertAction(title: "Cancel", style: UIAlertActionStyle.cancel, handler: {
                _ in print("Incorrect Username!!!! Try again");
            })
            alert.addAction(cancelAction);
            self.present(alert, animated: true, completion: nil);
        }
    }
    
    @IBAction func onClickBack(_ sender: UIBarButtonItem) {
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let mainViewController = storyBoard.instantiateViewController(withIdentifier: "tabBarScreen") as! UITabBarController
     //   self.present(mainViewController, animated: true, completion: nil);
        self.navigationController?.pushViewController(mainViewController, animated: true);
        
    }
}

extension UIButton{
    func applyButtonCssStyle1(){
        self.backgroundColor = UIColor.darkGray;
        self.layer.cornerRadius = self.frame.height / 2;
        self.setTitleColor(UIColor.white, for: UIControlState.normal);
        self.titleLabel?.font = UIFont.boldSystemFont(ofSize: 16)
        
        self.layer.shadowColor =    UIColor.white.cgColor;
        self.layer.shadowRadius = 2;
        self.layer.shadowOpacity = 0.5;
        self.layer.shadowOffset = CGSize(width:0,height:0);
    }
}
