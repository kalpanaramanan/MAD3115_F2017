//
//  RegisteredUserViewController.swift
//  HealthHabits
//
//  Created by MacStudent on 2017-10-18.
//  Copyright © 2017 MacStudent. All rights reserved.
//

import UIKit

class RegisteredUserViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    @IBAction func onClickStart(_ sender: UIButton) {
        
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let quizViewController = storyBoard.instantiateViewController(withIdentifier: "quizScreen") as! QuizViewController
        self.present(quizViewController, animated: true, completion: nil);
    }
    
    
    @IBAction func onClickInstructionButton(_ sender: UIButton) {
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let readMeViewController = storyBoard.instantiateViewController(withIdentifier: "instructionScreen") as! ReadMeViewController
        self.present(readMeViewController, animated: true, completion: nil);
    }
    
    @IBAction func onClickLogout(_ sender: UIBarButtonItem) {
        
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let loginViewController = storyBoard.instantiateViewController(withIdentifier: "loginScreen") as! LoginViewController
        self.present(loginViewController, animated: true, completion: nil);
    }
    
    
}
