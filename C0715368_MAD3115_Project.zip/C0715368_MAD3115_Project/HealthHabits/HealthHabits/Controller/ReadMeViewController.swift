//
//  ReadMeViewController.swift
//  HealthHabits
//
//  Created by MacStudent on 2017-10-18.
//  Copyright © 2017 MacStudent. All rights reserved.
//

import UIKit

class ReadMeViewController: UIViewController {
    @IBOutlet weak var webViewReadMe: UIWebView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        loadFromFile();
        
    }
    
    func loadFromFile() {
        let localFilePath = Bundle.main.url(forResource: "readme", withExtension: "html");
        let myRequest = URLRequest(url: localFilePath!);
        webViewReadMe.loadRequest(myRequest);
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

}
