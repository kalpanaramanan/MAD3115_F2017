//
//  ViewController.swift
//  HealthHabits
//
//  Created by MacStudent on 2017-10-18.
//  Copyright © 2017 MacStudent. All rights reserved.
//

import UIKit

class MainViewController: UIViewController {

    @IBOutlet weak var takeUpTheQuiz: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        takeUpTheQuiz.applyButtonCssStyle();
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func onClickTakeAQuiz(_ sender: UIButton) {
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let loginViewController = storyBoard.instantiateViewController(withIdentifier: "loginScreen") as! LoginViewController
        //self.present(loginViewController, animated: true, completion: nil);
        self.navigationController?.pushViewController(loginViewController, animated: true)
    }
    
    
}

extension UIButton{
    func applyButtonCssStyle(){
        self.backgroundColor = UIColor.darkGray;
        self.layer.cornerRadius = self.frame.height / 2;
        self.setTitleColor(UIColor.white, for: UIControlState.normal);
        self.titleLabel?.font = UIFont.boldSystemFont(ofSize: 16)

        self.layer.shadowColor =    UIColor.white.cgColor;
        self.layer.shadowRadius = 2;
        self.layer.shadowOpacity = 0.5;
        self.layer.shadowOffset = CGSize(width:0,height:0);
    }
}
