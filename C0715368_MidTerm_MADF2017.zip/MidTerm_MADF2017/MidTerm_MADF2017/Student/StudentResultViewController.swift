//
//  StudentResultViewController.swift
//  MidTerm_MADF2017
//
//  Created by moxDroid on 2017-10-20.
//  Copyright © 2017 moxDroid. All rights reserved.
//  Student ID : C0715368
//  Student Name : Kalpana Ramanan

import UIKit

class StudentResultViewController: UIViewController {

    var userID = UserDefaults.standard;
    @IBOutlet weak var lblUserID: UILabel!
    @IBOutlet weak var lblStudentBasicDetails: UILabel!
    @IBOutlet weak var lblStudentMarks: UILabel!
    @IBOutlet weak var lblStudentResult: UILabel!
    @IBOutlet weak var lblStudentGrade: UILabel!

    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        lblUserID.text = String(describing: userID.value(forKey: "UserID")!);
        let studentList = Student.getAllStudent();
        var resultMarks:Double = 0.0;
        var resultBasicDetials = String();
        var resultGrade = String();
        var sumMarks:Double = 0.0;
        for (key,value) in studentList {
            
            resultBasicDetials += "Student ID:\(key)\nStudent Name: \(value.studentName!) \nEmail: \(value.email!) \nBirth Date : \(value.birthDate!) \nMark1: \(value.mark1!) \nMark2: \(value.mark2!)\nMark3: \(value.mark3!)\nMark4: \(value.mark4!)\nMark5: \(value.mark5!)";
            sumMarks = (value.mark1! + value.mark2! + value.mark3! + value.mark4! + value.mark5! )
            resultMarks = ((sumMarks/500 )*100);
            
        }

        
        lblStudentBasicDetails.text = String(describing:resultBasicDetials);

        lblStudentMarks.text = "Total marks: \(sumMarks) \nPercentage:\(resultMarks) ";
        
        if( resultMarks < 45 )
        {
            lblStudentResult.textColor = UIColor.red;
            lblStudentResult.text = String("FAIL");
        }else{
            lblStudentResult.textColor = UIColor.green;
            lblStudentResult.text = String("PASS");
        }
        
        if resultMarks >= 95 {
            resultGrade = "A+";
        }else if ((resultMarks >= 85) && (resultMarks < 95 )){
            resultGrade = "A";
        }else if ((resultMarks >= 75) && (resultMarks < 85 )){
            resultGrade = "B+";
        }else if ((resultMarks >= 65) && (resultMarks < 75 )){
            resultGrade = "B";
        }else if ((resultMarks >= 55) && (resultMarks < 65 )){
            resultGrade = "C+";
        }else if ((resultMarks >= 50) && (resultMarks < 55 )){
            resultGrade = "C";
        }else if ((resultMarks >= 45) && (resultMarks < 50 )){
            resultGrade = "D+";
        }else{
            resultGrade = "F";
        }
        print(resultGrade)
        lblStudentGrade.text = String(resultGrade);
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
