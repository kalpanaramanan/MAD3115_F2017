//
//  Student.swift
//  MidTerm_MADF2017
//
//  Created by moxDroid on 2017-10-20.
//  Copyright © 2017 moxDroid. All rights reserved.
//  Student ID : C0715368
//  Student Name : Kalpana Ramanan

import Foundation

class Student {
    var studentId:Int!;
    var studentName:String!;
    var email:String!;
    var birthDate:Date!;
    //var marksArray = [Double]();
    var mark1:Double?;
    var mark2:Double?;
    var mark3:Double?;
    var mark4:Double?;
    var mark5:Double?;
    static var studentList = [Int:Student]();
    
    init(){
        studentId = 0;
        studentName = "";
        email = "";
        birthDate = Date();
        //marksArray = [];
        mark1 = 0.0;
        mark2 = 0.0;
        mark3 = 0.0;
        mark4 = 0.0;
        mark5 = 0.0;
    }
    
    init(_ studentId:Int,_ studentName:String,_ email:String, _ birthDate:Date,_ mark1:Double,_ mark2:Double,_ mark3:Double,_ mark4:Double,_ mark5:Double){
        self.studentId = studentId;
        self.studentName = studentName;
        self.email = email;
        self.birthDate = birthDate;
        //self.marksArray = marksArray;
        self.mark1 = mark1;
        self.mark2 = mark2;
        self.mark3 = mark3;
        self.mark4 = mark4;
        self.mark5 = mark5;
    }
    
    static func addStudent(student: Student){
        self.studentList[student.studentId!] = student;
    }
    
    static func getAllStudent()-> [Int:Student]{
        return self.studentList;
    }
    
}
