//
//  ViewController.swift
//  SamplePlistExample
//
//  Created by MacStudent on 2017-10-19.
//  Copyright © 2017 MacStudent. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        readFromPlist()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    func readFromPlist(){
        if let bundlePath = Bundle.main.path(forResource: "ProductPlist", ofType: "plist") {
            let dictionary = NSMutableDictionary(contentsOfFile: bundlePath)
            
            print(dictionary!.description)
            print(dictionary!["products"]!)
            let p = dictionary!["products"] as! NSDictionary
            print(p["productid"]!)
            print(p["productname"]!)
            print(p["productprice"]!)
        }
    }

}

