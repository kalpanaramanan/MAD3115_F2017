//
//  ViewController.swift
//  PickerDemo
//
//  Created by MacStudent on 2017-10-19.
//  Copyright © 2017 MacStudent. All rights reserved.
//

import UIKit

class PickerViewController: UIViewController,UIPickerViewDelegate,UIPickerViewDataSource {
 
    let userDefaultss = UserDefaults.standard
    
    
    @IBOutlet weak var btnButton: UIButton!
    
    @IBOutlet weak var pickerCountryList: UIPickerView!
    @IBOutlet weak var lblDisplayCountry: UILabel!

    
    
    let  pickerData = [
        ["India","Afghanistan","Bahrain","Brazil","Ecuador","Finland","Japan","UK","Sweden","Russia"],["Delhi","Kabul","Manama","Brasilia","Quito","Helsinki","Tokyo","London","Stockholm","Moscow"]
    ];
    
    /*"India": "Delhi","Afghanistan":"Kabul","Bahrain":"Manama","Brazil":"Brasilia","Ecuador":"Quito","Finland":"Helsinki","Japan":"Tokyo","UK":"London","Sweden":"Stockholm","Russia":"Moscow" */
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        pickerCountryList.dataSource = self;
        pickerCountryList.delegate = self;
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return pickerData.count;
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return pickerData[component].count;
    }
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
         return pickerData[component][row]
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        
        let size = pickerData[0][pickerCountryList.selectedRow(inComponent:0)]
        let topping = pickerData[1][pickerCountryList.selectedRow(inComponent:1)]
        lblDisplayCountry.text = "Country: " + size + " Capital City " + topping
        
        userDefaultss.set(lblDisplayCountry.text, forKey: "picker")
    }

  
    @IBAction func btnTapped(_ sender: UIButton) {
    }
    
}

