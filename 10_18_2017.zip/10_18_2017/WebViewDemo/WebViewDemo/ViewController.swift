//
//  ViewController.swift
//  WebViewDemo
//
//  Created by MacStudent on 2017-10-18.
//  Copyright © 2017 MacStudent. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var myWebView: UIWebView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        loadFromFile();
       
    }

    func loadFromFile() {
        let localFilePath = Bundle.main.url(forResource: "readme", withExtension: "html");
        let myRequest = URLRequest(url: localFilePath!);
        myWebView.loadRequest(myRequest);
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

