//
//  SecondViewController.swift
//  ThridExample
//
//  Created by MacStudent on 2017-10-18.
//  Copyright © 2017 MacStudent. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {

    var firstName:String!;
    var lastName:String!;
    var image = UIImage();
    @IBOutlet weak var mylblName: UILabel!
    @IBOutlet weak var myImageView: UIImageView!
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.mylblName.text =  firstName + " " + lastName;
        self.myImageView.image = image;
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewWillAppear(_ animated: Bool){
        
        self.navigationController?.setNavigationBarHidden(false, animated: false)
        //self.title = "First Screen";
        
    }
    
    @IBAction func onClickNextButton(_ sender: UIButton) {
        self.performSegue(withIdentifier: "thirdSegue", sender: self)
    }
    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
        print("Prepare inside");
        if let thirdVC = segue.destination as? ThirdViewController {
            thirdVC.myName = "Kalpana";
        }
    }
 

}
