//
//  ViewController.swift
//  ThridExample
//
//  Created by MacStudent on 2017-10-18.
//  Copyright © 2017 MacStudent. All rights reserved.
//

import UIKit

class FirstViewController: UIViewController {

    @IBOutlet weak var txtFirstName: UITextField!
    @IBOutlet weak var txtLastName: UITextField!
    @IBOutlet weak var myImageView: UIImageView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func viewWillAppear(_ animated: Bool){
        
        self.navigationController?.setNavigationBarHidden(false, animated: false)
        self.title = "First Screen";

    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    
    @IBAction func btnOnClickSubmit(_ sender: UIButton) {
        
        /* let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil) */
        let secondViewController = self.storyboard?.instantiateViewController(withIdentifier: "secondViewController") as! SecondViewController
        secondViewController.firstName = txtFirstName.text!
        secondViewController.lastName = txtLastName.text!;
        secondViewController.image = myImageView.image!;
        
       /* self.present(secondViewController, animated: true, completion: nil) */
        
    self.navigationController?.pushViewController(secondViewController, animated: true);
        
    }
    
}

